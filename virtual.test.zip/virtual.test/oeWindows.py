# -*- coding: utf-8 -*-

import xbmcgui

class mainWindow(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        pass
